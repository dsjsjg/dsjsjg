# checkpoints

Model checkpoints are saved here. If you want the model to be saved somewhere else (another `dir` for eg) make sure that you create the `dir` before training. Otherwise the trainer class will error out during training.
